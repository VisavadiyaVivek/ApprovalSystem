from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib import messages
from django.core.files.storage import FileSystemStorage 
from django.urls import reverse

from project.models import CustomUser, Guide,HOD,Team, Project,Admin,Student


def guide_home(request):
    user = CustomUser.objects.get(id=request.user.id)
    g_obj = Guide.objects.get(admin=user)
    t_obj = Team.objects.get(guide_id=g_obj.id)
    # s_obj = Student.objects.get(team_id=t_obj.id)
    # p_obj = Project.objects.get(p_id=t_obj.id)

    total_teams = Team.objects.filter(id=t_obj.id).count()
    total_students = Student.objects.filter(team_id=t_obj.id).count()
    total_projects = Project.objects.filter(p_id=t_obj.id).count()
    
    context = {
        "total_teams" : total_teams,
        "total_students" : total_students,
        "total_projects" : total_projects
        
    }
    return render(request,'project/guide_templates/guide_home.html',context)


def guide_profile(request):
    user = CustomUser.objects.get(id=request.user.id)
    g_id = Guide.objects.get(admin=user)
    context = {
        "g_id" : "g_id",
        "user" : user
    }

    return render(request, 'project/guide_templates/guide_profile.html', context)



def guide_profile_update(request):
    if request.method != "POST":
        messages.error(request, "Invalid Method!")
        return redirect('guide_profile')
    else:
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        password = request.POST.get('password')
        phone_number = request.POST.get('phone_number')
        department = request.POST.get('department')
        try:
            customuser = CustomUser.objects.get(id=request.user.id)
            customuser.first_name = first_name
            customuser.last_name = last_name
            if password != None and password != "":
                customuser.set_password(password)
            customuser.save()

            guide = Guide.objects.get(admin=customuser.id)
            guide.phone_number = phone_number
            guide.department = department
            guide.save()
            
            messages.success(request, "Guide Updated Successfully")
            return redirect('guide_profile')
        except:
            messages.error(request, "Failed to Update Guide")
            return redirect('guide_profile')



def guide_team_view(request):
    g_obj = Guide.objects.get(admin=request.user.id)
    t_obj_list = Team.objects.filter(guide_id=g_obj.id)
    p_obj_list = Project.objects.filter(p_id=t_obj_list)
    # st_obj_list = Student.objects.filter(team_id=t_obj.id)



    context = {
        "g_obj" : g_obj,
        "t_obj_list" : t_obj_list,
        # "p_obj" : p_obj,
        # "st_obj_list" : st_obj_list
    }

    return render(request,'project/guide_templates/guide_team_view.html',context)